const WA="254757411798",$=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const C=[
["eCitizen Services","Availability depends on the relevant government agency and your eligibility.",[["Birth certificate","Application and replacement assistance."],["Marriage certificate","Application assistance."],["Civil marriage registration","Registration and related applications."],["Death certificate","Application assistance."],["Certificate of good conduct","Application assistance."],["Business name registration","Search, reservation and registration."],["Company registration","Registration assistance."],["Application status follow-up","Official document applications and status checks."]]],
["NTSA Services","Some steps need official verification or in-person attendance.",[["Driving licence","Application and renewal assistance."],["Vehicle registration & logbook","Logbook-related applications."],["Ownership transfer","Motor vehicle transfer assistance."],["Inspection booking","Motor vehicle inspection booking."],["Driving test booking","Test booking assistance."],["Duplicate logbook","Application assistance."],["Smart driving licence","Where applicable."],["PSV applications & status checks","Where available, plus follow-up."]]],
["KRA Services","Tax services depend on your circumstances and supporting documents.",[["KRA PIN registration","New PIN registration."],["PIN certificate & amendments","Retrieval, reprinting and amendments."],["Tax returns filing","Individual and eligible taxpayers."],["Nil returns","Where applicable."],["Business tax registration","Registration and compliance help."],["Tax compliance certificate","Application assistance."],["iTax account help","Account access and support."],["Deadline guidance","Tax obligations and filing dates."]]],
["SHA Services","Some services need official verification or in-person attendance.",[["SHA registration","Social Health Authority registration help."],["Add dependants","For an eligible member's account."],["Household info updates","Where supported."],["Means testing","Assistance with the process."],["Member details correction","Update eligible member information."],["Registration status check","Check member status."],["Member portal access","Assistance accessing the portal."],["Contribution guidance","Contribution and payment status information."]]],
["Cyber Café Services","Price varies by job. Request a quotation.",[["CV writing & formatting","Professional CV preparation."],["Job applications","Online and email applications."],["College & university applications","Online applications."],["Typing & formatting","Documents, letters and business documents."],["Printing, copying & scanning","Everyday office services."],["Lamination & binding","Document finishing."],["Email creation & help","Set up and assistance."],["Passport photos","Photo preparation."],["PDF editing & conversion","Edit, convert and prepare."],["Online form filling","Application form assistance."]]]];
let cur=0;const tabs=$("#tabs"),cards=$("#cards");
C.forEach((c,i)=>{const b=document.createElement("button");b.textContent=c[0];b.setAttribute("role","tab");b.onclick=()=>{cur=i;$("#q").value="";draw()};tabs.append(b);
 $("#cat").add(new Option(c[0],i))});
function draw(){const q=$("#q").value.toLowerCase();[...tabs.children].forEach((b,i)=>b.setAttribute("aria-selected",!q&&i==cur));
 $("#tnote").textContent=q?"Search results across all categories":C[cur][1];
 let h="";C.forEach((c,i)=>{if(!q&&i!=cur)return;c[2].forEach((s,j)=>{if(q&&!(s[0]+s[1]+c[0]).toLowerCase().includes(q))return;
 h+=`<div class="card"><h3>${esc(s[0])}</h3><p>${esc(s[1])}</p><button class="btn" data-o="${i}.${j}">Order Now</button></div>`})});
 cards.innerHTML=h||"<p>No matching service. Contact us and we will help.</p>"}
$("#q").oninput=draw;
cards.onclick=e=>{const o=e.target.dataset.o;if(!o)return;const[i,j]=o.split(".");$("#cat").value=i;fillSv();$("#sv").value=j;$("#order").scrollIntoView()};
document.querySelectorAll("footer [data-c]").forEach(a=>a.onclick=()=>{cur=+a.dataset.c;draw()});
function fillSv(){const s=$("#sv");s.innerHTML="";C[$("#cat").value][2].forEach((x,j)=>s.add(new Option(x[0],j)))}
$("#cat").onchange=fillSv;fillSv();draw();$("#yr").textContent=new Date().getFullYear();

let db=null,user=null;
(async()=>{try{if(window.claude){db=await claude.use("db");user=await claude.use("user");if(db){loadRev();if(user&&user.canEdit&&user.canEdit())loadAdmin()}}}catch(e){db=null}})();

$("#of").onsubmit=async e=>{e.preventDefault();let bad=0;const n=$("#n").value.trim(),p=$("#p").value.replace(/[\s-]/g,"");
 $("#e-n").textContent=n.length<2?(bad=1,"Please enter your full name."):"";
 $("#e-p").textContent=/^(\+?254|0)[17]\d{8}$/.test(p)?"":(bad=1,"Enter a valid Kenyan phone number.");
 $("#e-pv").textContent=$("#pv").checked?"":(bad=1,"Please accept the privacy notice.");
 if(bad)return;
 const d=new Date(),ref="DCC-"+String(d.getFullYear()).slice(2)+String(d.getMonth()+1).padStart(2,"0")+String(d.getDate()).padStart(2,"0")+"-"+Math.random().toString(36).slice(2,6).toUpperCase();
 const cat=C[$("#cat").value],sv=cat[2][$("#sv").value][0];
 const o={ref,name:n,phone:p,email:$("#em").value.trim(),contact:$("#cm").value,category:cat[0],service:sv,details:$("#ds").value.trim().slice(0,800),date:$("#dt").value,status:"Order Received",at:d.toISOString()};
 let saved=false;if(db){try{await db.collection("orders").doc(ref).set(o);saved=true}catch(x){}}
 const msg=`New order ${ref}\nName: ${n}\nPhone: ${p}\nCategory: ${cat[0]}\nService: ${sv}\nDetails: ${o.details||"-"}\nPreferred date: ${o.date||"-"}\nContact via: ${o.contact}`;
 $("#result").innerHTML=`<div class="ok" role="status"><h3>Almost done! Order ${esc(ref)}</h3><p>Your order has <b>not</b> reached us yet. Tap below to send it to DAIKAH CYBER CENTRE on WhatsApp, or by email. Keep your reference number.</p>
 <div class="cta"><a class="btn wa" target="_blank" rel="noopener" href="https://wa.me/${WA}?text=${encodeURIComponent(msg)}">Send Order on WhatsApp</a><a class="btn o" href="mailto:cybercafe01001@gmail.com?subject=${encodeURIComponent("Order "+ref)}&body=${encodeURIComponent(msg)}">Send by Email</a></div>
 ${saved?"<p><small>A copy was also saved to the order system.</small></p>":""}</div>`;
 $("#of").reset();fillSv();$("#result").scrollIntoView()};

$("#trb").onclick=()=>{const r=$("#tr").value.trim().toUpperCase();if(!/^DCC-\d{6}-[A-Z0-9]{4}$/.test(r)){$("#tre").textContent="Enter a valid reference, e.g. DCC-261015-AB12.";return}
 $("#tre").textContent="";open(`https://wa.me/${WA}?text=${encodeURIComponent("Hello, please update me on order "+r)}`,"_blank")};

$("#cf").onsubmit=e=>{e.preventDefault();const m=$("#cn").value.trim();if(!m){$("#ce").textContent="Please type a message.";return}$("#ce").textContent="";open(`https://wa.me/${WA}?text=${encodeURIComponent(m)}`,"_blank")};

let rate=0;const st=$("#st");for(let i=1;i<=5;i++){const b=document.createElement("button");b.type="button";b.textContent="☆";b.setAttribute("role","radio");b.setAttribute("aria-label",i+" star"+(i>1?"s":""));b.onclick=()=>{rate=i;[...st.children].forEach((x,k)=>x.textContent=k<i?"★":"☆")};st.append(b)}
$("#rf").onsubmit=async e=>{e.preventDefault();const t=$("#rt").value.trim();if(!rate||t.length<10){$("#re").textContent="Choose a rating and write at least 10 characters.";return}
 if(!db){$("#re").textContent="Reviews can't be submitted right now. Please try later or leave a Google review.";return}
 try{const id="r"+Date.now().toString(36)+Math.random().toString(36).slice(2,5);await db.collection("reviews").doc(id).set({name:$("#rn").value.trim().slice(0,40)||"Customer",rating:rate,text:t.slice(0,500),at:new Date().toISOString(),approved:false});
 $("#re").textContent="Thank you! Your review will appear after approval.";$("#rf").reset();rate=0;[...st.children].forEach(x=>x.textContent="☆")}catch(x){$("#re").textContent="Could not submit review."}};
async function loadRev(){try{const s=await db.collection("reviews").get();const L=[];s.forEach(d=>{const v=d.data?d.data():d;if(v&&v.approved)L.push(v)});
 if(!L.length)return;L.sort((a,b)=>b.at>a.at?1:-1);const av=L.reduce((a,b)=>a+b.rating,0)/L.length;$("#avg").textContent=`${av.toFixed(1)} / 5 from ${L.length} approved review${L.length>1?"s":""} (customer-submitted)`;
 $("#rl").innerHTML=L.slice(0,6).map(v=>`<div class="card"><div style="color:var(--gold)" aria-label="${v.rating} stars">${"★".repeat(v.rating)}${"☆".repeat(5-v.rating)}</div><p>${esc(v.text)}</p><small>${esc(v.name)} · ${esc(v.at.slice(0,10))}</small></div>`).join("")}catch(e){}}
async function loadAdmin(){$("#admin").hidden=false;const A=$("#al");try{const [o,r]=await Promise.all([db.collection("orders").get(),db.collection("reviews").get()]);
 const O=[],R=[];o.forEach(d=>O.push(d.data?d.data():d));r.forEach(d=>R.push({id:d.id,...(d.data?d.data():d)}));O.sort((a,b)=>b.at>a.at?1:-1);
 const S=["Order Received","Awaiting Customer Information","Quotation Sent","Awaiting Payment","In Progress","Awaiting Official Verification","Completed","Cancelled"];
 A.innerHTML=`<input id="af" placeholder="Search orders…" style="margin-bottom:10px"><table id="at">${O.map(x=>`<tr data-s="${esc(JSON.stringify(x)).toLowerCase()}"><td><b>${esc(x.ref)}</b><br>${esc(x.name)} · ${esc(x.phone)}</td><td>${esc(x.service)}</td><td><select data-r="${esc(x.ref)}">${S.map(s=>`<option ${s==x.status?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("")||"<tr><td>No orders yet</td></tr>"}</table>
 <h3 style="margin-top:16px">Reviews</h3><table>${R.map(x=>`<tr><td>${"★".repeat(x.rating)} ${esc(x.text)}<br><small>${esc(x.name)}</small></td><td>${x.approved?"Approved":`<button class="btn" data-a="${x.id}">Approve</button>`}</td></tr>`).join("")||"<tr><td>None</td></tr>"}</table>`;
 $("#af").oninput=e=>document.querySelectorAll("#at tr").forEach(t=>t.hidden=!(t.dataset.s||"").includes(e.target.value.toLowerCase()));
 A.onchange=async e=>{const r=e.target.dataset.r;if(r)await db.collection("orders").doc(r).update({status:e.target.value})};
 A.onclick=async e=>{const a=e.target.dataset.a;if(a){await db.collection("reviews").doc(a).update({approved:true});e.target.replaceWith("Approved");loadRev()}}}catch(e){A.textContent="Could not load data."}}
